<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              www.facebook.com/lal.saroj.1
 * @since             1.0.0
 * @package           Book_Plugin
 *
 * @wordpress-plugin
 * Plugin Name:       book-plugin
 * Plugin URI:        www.facebook.com/lal.saroj.1
 * Description:       This plugin gives a quick features of a custom post type,taxonomies,meta boxes for Book.
 * Version:           1.0.0
 * Author:            Sarojkumar
 * Author URI:        www.facebook.com/lal.saroj.1
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       book-plugin
 * Domain Path:       /languages
 */

define("PLUGIN_DIR_PATH", plugin_dir_path(__FILE__));
define("PLUGIN_URL", plugins_url());
define("PLUGIN_VERSION", "1.0.0");

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define('BOOK_PLUGIN_VERSION', '1.0.0');

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-book-plugin-activator.php
 */
function activate_book_plugin()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-book-plugin-activator.php';
    Book_Plugin_Activator::activate();
    
    //Code for the functionalities//
    
    global $wpdb;
    $labels = array(
        'name' => 'Book',
        'singular_name' => 'Book',
        'add_new' => 'Add Book',
        'add_new_item' => 'Add New Book',
        'all_items' => 'All Books',
        'edit_item' => 'Edit Book',
        'update_item' => 'Update Book',
        'new_item' => 'New Book',
        'view_item' => 'View Book',
        'search_item' => 'Search Book',
        'not_found' => 'No Book found',
        'not_found_in_trash' => 'No Books found in trash',
        'parent_item_colon' => 'Parent Item'
    );
    $args   = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'publicly_queryable' => true,
        'query_var' => true,
        'rewrite' => true,
        'capatibility_type' => 'post',
        'hierarchical' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menu' => true,
        'show_in_admin_bar' => true,
        'support' => array(
            'title',
            'editor',
            'excerpt',
            'author',
            'thumbnail',
            'revisions',
            'custom-fields'
        ),
        //'taxonomies' => array( 'category', 'post_tag' ),
        'menu_position' => 5,
        'exclude_from_search' => false,
        'can_export' => true
        
    );
    register_post_type('book', $args);
    
    //Custom hierarchical taxonomy
    $labels = array(
        'name' => 'Book Category',
        'singular_name' => 'Book Category',
        'search_items' => 'Search Book Categories',
        'all_items' => 'All Book Categories',
        'parent_item' => 'Parent Book Category',
        'parent_item_colon' => 'Parent Book Category:',
        'edit_item' => 'Edit Book Category',
        'update_item' => 'Update Book Category',
        'add_new_item' => 'Add New Book Category',
        'new_item_name' => 'New Book Category Name',
        'menu_name' => 'Book Category'
    );
    $args   = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'book_category'
        )
    );
    register_taxonomy('type', array(
        'book'
    ), $args);
    
    //Custom Non-hierarchical taxonomy
    $labels = array(
        'name' => 'Book Tag',
        'singular_name' => 'Book Tag',
        'search_items' => 'Search Book Tags',
        'all_items' => 'All Book Tags',
        'parent_item' => 'Parent Book Tag',
        'parent_item_colon' => 'Parent Book Tag:',
        'edit_item' => 'Edit Book Tag',
        'update_item' => 'Update Book Tag',
        'add_new_item' => 'Add New Book Tag',
        'new_item_name' => 'New Book Tag Name',
        'menu_name' => 'Book Tag'
    );
    $args   = array(
        'hierarchical' => false,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'book_tag'
        )
    );
    register_taxonomy('tag', array(
        'book'
    ), $args);
    
    //Create table while activating plugin
    require_once(ABSPATH . "wp-admin/includes/upgrade.php");
    if (!($wpdb->get_var(' SHOW TABLES LIKE "wp_books" '))) {
        $create_tbl = "CREATE TABLE `wp_books` (
                `book_id` bigint(20) NOT NULL AUTO_INCREMENT,
                `book_name` varchar(255) NOT NULL,
                `book_author` varchar(255) NOT NULL,
                `book_price` float NOT NULL,
                `book_publisher` varchar(255) NOT NULL,
                `book_year` int(4) NOT NULL,
                `book_edition` varchar(155) NOT NULL,
                `book_url` varchar(255) NOT NULL,
                PRIMARY KEY (`book_id`)
               ) ENGINE=InnoDB DEFAULT CHARSET=latin1";
        
        dbDelta($create_tbl);
    }
    
    //Custom meta table for book post type
    if (!($wpdb->get_var(' SHOW TABLES LIKE "wp_affiliate_wp_affiliatemeta" '))) {
        $create_tbl = "CREATE TABLE `wp_affiliate_wp_affiliatemeta` (`meta_id` bigint(20) NOT NULL AUTO_INCREMENT,`affiliate_id` bigint(20) NOT NULL DEFAULT '0',`meta_key` varchar(255) DEFAULT NULL,`meta_value` longtext,PRIMARY KEY (`meta_id`),KEY `affiliate_id` (`affiliate_id`),KEY `meta_key` (`meta_key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8";
        
        dbDelta($create_tbl);
    }
    //Code completes//
}
add_action('init', 'activate_book_plugin');

// function pw_register_metadata_table() { 	
//     global $wpdb;

//  }
//  add_action( 'plugins_loaded', 'pw_register_metadata_table' );



// Registering our meta table instead of default metapost table//
function pw_register_metadata_table()
{
    global $wpdb;
    $wpdb->affiliatemeta = $wpdb->prefix . 'bookmeta';
}
add_action('plugins_loaded', 'pw_register_metadata_table');

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-book-plugin-deactivator.php
 */
function deactivate_book_plugin()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-book-plugin-deactivator.php';
    Book_Plugin_Deactivator::deactivate();
    flush_rewrite_rules();
}

register_activation_hook(__FILE__, 'activate_book_plugin');
register_deactivation_hook(__FILE__, 'deactivate_book_plugin');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path(__FILE__) . 'includes/class-book-plugin.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_book_plugin()
{
    
    $plugin = new Book_Plugin();
    $plugin->run();
    
}
run_book_plugin();

//Settings and custom meta-boxes Codes//

function book_custom_metabox()
{
    add_meta_box('contact_email', 'User Email', 'custom_contact_email_callback', 'book', 'side');
}
add_action('add_meta_boxes', 'book_custom_metabox');

//Callback func for meta box
function custom_contact_email_callback($post)
{
    wp_nonce_field('book_email_save_data', 'custom_contact_email_nonce');
    $value = get_post_meta($post->ID, '_book_email_value_key', true);
    echo '<label for="book_email_field">User Email Address: </label><br>';
    echo '<input type="email" id="book_email_field" name="book_email_field" value="' . esc_attr($value) . '" />';
}
function book_email_save_data($post_id)
{
    if (!isset($_POST['custom_contact_email_nonce'])) {
        return;
    }
    if (!wp_verify_nonce($_POST['custom_contact_email_nonce'], 'book_email_save_data')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    if (!isset($_POST['book_email_field'])) {
        return;
    }
    $my_data = sanitize_text_field($_POST['book_email_field']);
    update_post_meta($post_id, '_book_email_value_key', $my_data);
}
add_action('save_post', 'book_email_save_data');


//custom settings for book
global $options;
class MySettingsPage
{
    /**
     * Holds the values to be used in the fields callbacks
     */
    //private $options;
    /**
     * Start up
     */
    public function __construct()
    {
        add_action('admin_menu', array(
            $this,
            'add_plugin_page'
        ));
        add_action('admin_init', array(
            $this,
            'page_init'
        ));
        add_action('admin_menu', array(
            $this,
            'add_settings_menu'
        ));
    }
    
    /**
     * Add options page
     */
    public function add_plugin_page()
    {
        // This page will be under "Book Post"
        add_submenu_page('edit.php?post_type=book', 'Book Settings', 'Book Settings', 'manage_options', 'my-setting-admin', array(
            $this,
            'create_admin_page'
        ));
    }
    
    /**
     * Options page callback
     */
    public function create_admin_page()
    {
        // Set class property
        $this->options = get_option('my_option_name');
?>
    <div class="wrap">
        <h1>My Settings</h1>
        <form method="post" action="options.php">
        <?php
        // This prints out all hidden setting fields
        settings_fields('my_option_group');
        do_settings_sections('my-setting-admin');
        submit_button();
?>
        </form>
    </div>
    <?php
    }
    public function add_settings_menu()
    {
        
        
    }
    
    /**
     * Register and add settings
     */
    public function page_init()
    {
        register_setting('my_option_group', // Option group
            'my_option_name', // Option name
            array(
            $this,
            'sanitize'
        ) // Sanitize
            );
        
        add_settings_section('setting_section_id', // ID
            'My Custom Settings', // Title
            array(
            $this,
            'print_section_info'
        ), // Callback
            'my-setting-admin' // Page
            );
        
        add_settings_field('id_number', // ID
            'ID Number', // Title 
            array(
            $this,
            'id_number_callback'
        ), // Callback
            'my-setting-admin', // Page
            'setting_section_id' // Section           
            );
        
        add_settings_field('title', 'Title', array(
            $this,
            'title_callback'
        ), 'my-setting-admin', 'setting_section_id');
        add_settings_field('no_posts', 'No of Posts', array(
            $this,
            'no_posts_callback'
        ), 'my-setting-admin', 'setting_section_id');
    }
    
    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    public function sanitize($input)
    {
        $new_input = array();
        if (isset($input['id_number']))
            $new_input['id_number'] = absint($input['id_number']);
        
        if (isset($input['title']))
            $new_input['title'] = sanitize_text_field($input['title']);
        
        if (isset($input['no_posts']))
            $new_input['no_posts'] = sanitize_text_field($input['no_posts']);
        
        return $new_input;
    }
    
    /** 
     * Print the Section text
     */
    public function print_section_info()
    {
        print 'Enter your settings below:';
    }
    
    /** 
     * Get the settings option array and print one of its values
     */
    public function id_number_callback()
    {
        printf('<input type="text" id="id_number" name="my_option_name[id_number]" value="%s" />', isset($this->options['id_number']) ? esc_attr($this->options['id_number']) : '');
    }
    
    /** 
     * Get the settings option array and print one of its values
     */
    public function title_callback()
    {
        printf('<input type="text" id="title" name="my_option_name[title]" value="%s" />', isset($this->options['title']) ? esc_attr($this->options['title']) : '');
    }
    public function no_posts_callback()
    {
        printf('<input type="number" id="no_posts" name="my_option_name[no_posts]" value="%s" />', isset($this->options['no_posts']) ? esc_attr($this->options['no_posts']) : '');
    }
    
    
}

//Code for Setting the posts per page
$options = (get_option('my_option_name'));
$no      = $optioons['no_posts'];
$no1     = get_option('my_option_name[no_posts]');
$args    = array(
    'posts_per_page' => $no,
    'post_type' => 'book'
);
$myposts = get_posts($args);

function set_posts_per_page_for_books($query)
{
    $options = (get_option('my_option_name'));
    $no      = $options['no_posts'];
    $no1     = get_option('my_option_name[no_posts]');
    if (!is_admin() && $query->is_main_query() && is_post_type_archive('book')) {
        $query->set('posts_per_page', $no);
    }
}
add_action('pre_get_posts', 'set_posts_per_page_for_books');


//Code for inserting meta box data in custom meta table
//short code
//metadata for deals

function wpse_add_custom_meta_box_2()
{
    add_meta_box('custom_meta_box-2', // $id
        'Book Form', // $title
        'show_custom_meta_box_2', // $callback
        'book', // $page
        'normal', // $context
        'high' // $priority
        );
}
add_action('add_meta_boxes', 'wpse_add_custom_meta_box_2');


//showing custom form fields
function show_custom_meta_box_2($object)
{
    global $post;
    
    // Use nonce for verification to secure data sending
    wp_nonce_field(basename(__FILE__), 'wpse_our_nonce');
    
?>

<!-- //Include the form file for inserting book info// -->
 <?php
    include_once PLUGIN_DIR_PATH . "book-form.php";
}
//save data
// function wpse_save_meta_fields($post_id)
// {

//     // verify nonce
//     if (!isset($_POST['wpse_our_nonce']) || !wp_verify_nonce($_POST['wpse_our_nonce'], basename(__FILE__)))
//         return 'nonce not verified';

//     // check autosave
//     if (wp_is_post_autosave($post_id))
//         return 'autosave';

//     //check post revision
//     if (wp_is_post_revision($post_id))
//         return 'revision';

//     // check permissions
//     if ('book' == $_POST['post_type']) {
//         if (!current_user_can('edit_page', $post_id))
//             return 'cannot edit page';
//     } elseif (!current_user_can('edit_post', $post_id)) {
//         return 'cannot edit post';
//     }

//     //so our basic checking is done, now we can grab what we've passed from our newly created form
//     $wpse_value = $_POST['wpse_value'];
//     $wpse_key   = 'WPSE_KEY';
//     //simply we have to save the data now
//     global $wpdb;

//     $table = $wpdb->base_prefix . 'bookmeta';

//     //    $wpdb->insert(
//     //              $table,
//     //              array(
//     //                  'post_id' => $post_id, //as we are having it by default with this function
//     //                  'meta_value'   => $wpse_value , //assuming we are passing numerical value
//     //                  'meta_key' => $wpse_key
//     //   ),
//     //              array(
//     //                  '%d', //%s - string, %d - integer, %f - float
//     //                  '%s', //%s - string, %d - integer, %f - float
//     //                  '%s',
//     //   )
//     //            );
//     update_metadata( 'affiliate', $post_id, $wpse_key, $wpse_value );

// }
// add_action('save_post', 'wpse_save_meta_fields', 10, 3);
// add_action('new_to_publish', 'wpse_save_meta_fields');

//Registering our meta table
// function pw_register_metadata_table(){
//     global $wpdb;
//     $wpdb->affiliatemeta = $wpdb->prefix . 'bookmeta';
// }
// add_action( 'plugins_loaded', 'pw_register_metadata_table', 11 );


// override normal meta methods with custom methods 
function book_meta_install()
{
    global $wpdb;
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    
    $table_name = $wpdb->prefix . 'booksmeta';
    
    // see wpdb_get_schema() in https://github.com/WordPress/WordPress/blob/master/wp-admin/includes/schema.php
    $max_index_length = 191;
    
    
    $install_query = "CREATE TABLE $table_name (
		meta_id bigint(20) unsigned NOT NULL auto_increment,
		book_id bigint(20) unsigned NOT NULL default '0',
		meta_key varchar(255) default NULL,
		meta_value longtext,
		PRIMARY KEY  (meta_id),
		KEY book (book_id),
		KEY meta_key (meta_key($max_index_length))
	)";
    
    dbDelta($install_query);
}

register_activation_hook(__FILE__, 'book_meta_install');

// hook into init for single site, priority 0 = highest priority
add_action('init', 'bookmeta_integrate_wpdb', 0);
// hook in to switch blog to support multisite
add_action('switch_blog', 'bookmeta_integrate_wpdb', 0);
/**
 * Integrates badgemeta table with $wpdb
 *
 */
function bookmeta_integrate_wpdb()
{
    global $wpdb;
    
    $wpdb->bookmeta = $wpdb->prefix . 'booksmeta';
    $wpdb->tables[] = 'booksmeta';
    
    return;
}

/**
 * Adds meta data field to a badge.
 *
 * @param int    $badge_id    Badge ID.
 * @param string $meta_key   Metadata name.
 * @param mixed  $meta_value Metadata value.
 * @param bool   $unique     Optional, default is false. Whether the same key should not be added.
 * @return int|false Meta ID on success, false on failure.
 */
function add_book_meta($book_id, $meta_key, $meta_value, $unique = false)
{
    return add_metadata('book', $book_id, $meta_key, $meta_value, $unique);
}
/**
 * Removes metadata matching criteria from a badge.
 *
 * You can match based on the key, or key and value. Removing based on key and
 * value, will keep from removing duplicate metadata with the same key. It also
 * allows removing all metadata matching key, if needed.
 *
 * @param int    $badge_id    Badge ID
 * @param string $meta_key   Metadata name.
 * @param mixed  $meta_value Optional. Metadata value.
 * @return bool True on success, false on failure.
 */
function delete_book_meta($book_id, $meta_key, $meta_value = '')
{
    return delete_metadata('book', $book_id, $meta_key, $meta_value);
}
/**
 * Retrieve meta field for a badge.
 *
 * @param int    $badge_id Badge ID.
 * @param string $key     Optional. The meta key to retrieve. By default, returns data for all keys.
 * @param bool   $single  Whether to return a single value.
 * @return mixed Will be an array if $single is false. Will be value of meta data field if $single is true.
 */
function get_book_meta($book_id, $key = '', $single = false)
{
    return get_metadata('book', $book_id, $key, $single);
}
/**
 * Update badge meta field based on badge ID.
 *
 * Use the $prev_value parameter to differentiate between meta fields with the
 * same key and badge ID.
 *
 * If the meta field for the user does not exist, it will be added.
 *
 * @param int    $badge_id   Badge ID.
 * @param string $meta_key   Metadata key.
 * @param mixed  $meta_value Metadata value.
 * @param mixed  $prev_value Optional. Previous value to check before removing.
 * @return int|bool Meta ID if the key didn't exist, true on successful update, false on failure.
 */
function update_book_meta($book_id, $meta_key, $meta_value, $prev_value = '')
{
    return update_metadata('book', $book_id, $meta_key, $meta_value, $prev_value);
}


//save data in custom fields
function save_custom_meta_box($post_id, $post, $update)
{
    // verify nonce
    if (!isset($_POST['wpse_our_nonce']) || !wp_verify_nonce($_POST['wpse_our_nonce'], basename(__FILE__)))
        return 'nonce not verified';
    // // check autosave
    // if (wp_is_post_autosave($post_id))
    //     return 'autosave';
    
    // //check post revision
    // if (wp_is_post_revision($post_id))
    //     return 'revision';
    
    if (!current_user_can("edit_post", $post_id))
        return $post_id;
    
    if (defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
        return $post_id;
    
    $slug = "book";
    if ($slug != $post->post_type)
        return $post_id;
    
    if (isset($_POST["wpse_value"])) {
        $meta_box_text_value = $_POST["wpse_value"];
    }
    update_book_meta($post_id, "meta-box-text", $meta_box_text_value);
    if (isset($_POST["book_author"])) {
        $book_author = $_POST["book_author"];
    }
    update_book_meta($post_id, "meta_box_book_author", $book_author);
    if (isset($_POST["book_price"])) {
        $book_price = $_POST["book_price"];
    }
    update_book_meta($post_id, "meta_box_book_price", $book_price);
    if (isset($_POST["book_publisher"])) {
        $book_publisher = $_POST["book_publisher"];
    }
    update_book_meta($post_id, "meta_box_book_publisher", $book_publisher);
    if (isset($_POST["book_publishing_year"])) {
        $book_publishing_year = $_POST["book_publishing_year"];
    }
    update_book_meta($post_id, "meta_box_book_publishing_year", $book_publishing_year);
    if (isset($_POST["book_edition"])) {
        $book_edition = $_POST["book_edition"];
    }
    update_book_meta($post_id, "meta_box_book_edition", $book_edition);
    if (isset($_POST["book_url"])) {
        $book_url = get_post_permalink($post_id);
    }
    update_book_meta($post_id, "meta_box_book_url", $book_url);
    
}

add_action("save_post", "save_custom_meta_box", 10, 3);

//Short-code
//Create a shortcode [book] to display the book(s) information. Shortcode attributes should be id, author_name, year, category, tag, and publisher.

function show_book_info($atts, $post)
{
    // Attributesglobal $wpdb;
    global $wpdb;
    $post_id = get_the_ID();
    
    
    //Query for getting categories based on ID's
    $query = "select *from wp_term_relationships,wp_terms where object_id='.$post_id.' and  wp_term_relationships.term_taxonomy_id=wp_terms.term_id ";
    $var   = $wpdb->get_results($query);
    foreach ($var as $rows) {
        $category_name = $rows->name;
    }
    
    $querystr = "
            SELECT wp_posts.ID, wp_posts.post_title, wp_booksmeta.meta_key, wp_booksmeta.meta_value
            FROM wp_posts, wp_booksmeta
            WHERE wp_posts.ID = wp_booksmeta.book_id
            AND wp_booksmeta.meta_key NOT LIKE '\_%'
            AND wp_posts.post_type='book'
            AND wp_posts.post_status = 'publish'
    AND wp_booksmeta.book_id=" . $post_id;
    
    
    //wordpress function that returns the query as an array of associative arrays
    $results = $wpdb->get_results($querystr, ARRAY_A);
    
    //create an empty array
    $events = array();
    foreach ($results as $row) {
        //if row's ID doesn't exist in the array, add a new array
        if (!isset($events[$row['ID']])) {
            $events[$row['ID']] = array();
        }
        //add all the values to the array with matching IDs
        $events[$row['ID']] = array_merge($events[$row['ID']], array(
            'post_title' => $row['post_title']
        ), array(
            $row['meta_key'] => $row['meta_value']
        ));
        $id                 = $events[$row['ID']];
    }
    
    // Getting the category name and tag name //
    $cat = get_the_terms($post->ID, 'type');
    $tag = get_the_terms($post->ID, 'tag');
    
    //extract data from each event
    // foreach ($events as $event) {
    
    
    // echo $event['meta_box_book_author']; echo"<br>"; //can also echo specific metavalues etc.
    // echo $event['meta_box_book_price']; //can also echo specific metavalues etc.
    
    // }
    include_once PLUGIN_DIR_PATH . "show-posts.php";
    
}
add_shortcode('book', 'show_book_info');

//Code for custom Widget//
//Code for category and tags wise showing of books(Custom Widget)

/*
*custom widgets
*/

add_action('wp_dashboard_setup', 'my_custom_dashboard_widgets');
  
function my_custom_dashboard_widgets() {
global $wp_meta_boxes;
 
wp_add_dashboard_widget('custom_help_widget', 'Show top 5 category', 'custom_dashboard_help');
}
 
function custom_dashboard_help() {
    $categories = get_categories([
        'taxonomy' => 'type',
        'orderby'  => 'count',
        'order'    => 'DESC',
        'number'    =>'5'
        ]);
    
    ?>
    <ul>
 
    <?php foreach ($categories as $category) { ?>
        <li><?php echo $category->name; echo '('; echo $category->count; echo ')';?>
          
    
    <?php }?>
     </ul>
 
 
    
<?php } 
// Register and load the widget
function wpb_load_widget() {
    register_widget( 'wpb_widget' );
}
add_action( 'widgets_init', 'wpb_load_widget' );
 
// Creating the widget for side bar 
class wpb_widget extends WP_Widget {
 
function __construct() {
parent::__construct(
 
// Base ID of your widget
'wpb_widget', 
 
// Widget name will appear in UI
__('Custom Widgets', 'wpb_widget_domain'), 
 
// Widget description
array( 'description' => __( 'category show for custom post type', 'wpb_widget_domain' ), ) 
);
}
 
// Creating widget front-end
 
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
 
// before and after widget arguments are defined by themes
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
 
// This is where you run the code and display the output


$taxonomy = 'type';
$terms = get_terms($taxonomy); // Get all terms of a taxonomy

if ( $terms && !is_wp_error( $terms ) ) :


?>
    <ul>
        <?php foreach ( $terms as $term ) { ?>
            <li><a href="<?php echo get_term_link($term->slug, $taxonomy); ?>"><?php echo $term->name;  echo  '(';
            echo $term->count; echo ')';?></a></li>
        <?php } ?>
    </ul>
<?php endif;
}
// Widget Backend 
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'New title', 'wpb_widget_domain' );
}
// Widget admin form
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<?php 
}
     
// Updating widget replacing old instances with new
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
return $instance;
}
} // Class wpb_widget ends here


if (is_admin())
    $my_settings_page = new MySettingsPage();

//Settings and custom meta-boxes Code Ends//

?>