<head>
<style>

.label-class{
  color:red;
  font-style:italic;
  float:left;
}

</style>
</head>
<!-- <!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="<?php echo PLUGIN_URL.'/books-plugin/public/js/bootstrap.min.css' ?>">
  <script src="<?php echo PLUGIN_URL.'/books-plugin/public/js/jquery.min.js' ?>"></script>
  <script src="<?php echo PLUGIN_URL.'/books-plugin/public/js/bootstrap.min.js' ?>"></script>
</head>
<body>
<h2>Book Info</h2> -->
    <!-- <div class="form-group">
      <label for="book_author">Book ID:</label>
      <label>
        <?php
                    echo $post; //Book Author
                
        ?>
      </label>
    </div>
    <div class="form-group">
      <label for="book_author">Book Author:</label>
      <label>
        <?php
                foreach ($events as $event) {
                    echo $event['meta_box_book_author']; //Book Author
                }
        ?>
      </label>
    </div>
    <div class="form-group">
      <label for="book_price">Book Price:</label>
      <label>
        <?php
                foreach ($events as $event) {
                    echo $event['meta_box_book_price']; //Book Price
                }
        ?>
      </label>
    </div>
    <div class="form-group">
      <label for="book_publisher">Book Publisher:</label>
      <label>
        <?php
                foreach ($events as $event) {
                    echo $event['meta_box_book_publisher']; //Book Publisher
                }
        ?>
      </label>
    </div>
    

</body>
</html> -->
<label class="label-class">Book ID :: </label>
<label>
        <?php
                    echo $post_id; //Book Author
                
        ?>
</label>
<label class="label-class">Book Price:</label>
<label>
        <?php
                foreach ($events as $event) {
                    echo $event['meta_box_book_price']; //Book Price
                }
        ?>
</label>
<label class="label-class">Book Category:</label>
<label>
        <?php
              if( $cat[0]->name == "" )
              {
                echo 'No Category';
              }
              else{
                echo $cat[0]->name;
              }
        ?>
</label>
<label class="label-class">Book Tag:</label>
<label>
        <?php
                echo $tag[0]->name;
        ?>
</label>
<label class="label-class">Author :: </label>  
<label>
        <?php
                foreach ($events as $event) {
                    echo $event['meta_box_book_author']; //Book Publisher
                }
        ?>
</label>
<label class="label-class">Publisher :: </label>  
<label>
        <?php
                foreach ($events as $event) {
                    echo $event['meta_box_book_publisher']; //Book Publisher
                }
        ?>
</label>
