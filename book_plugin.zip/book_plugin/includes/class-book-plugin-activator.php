<?php

/**
 * Fired during plugin activation
 *
 * @link       www.facebook.com/lal.saroj.1
 * @since      1.0.0
 *
 * @package    Book_Plugin
 * @subpackage Book_Plugin/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Book_Plugin
 * @subpackage Book_Plugin/includes
 * @author     Sarojkumar <sarojlal50@gmail.com>
 */
class Book_Plugin_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
